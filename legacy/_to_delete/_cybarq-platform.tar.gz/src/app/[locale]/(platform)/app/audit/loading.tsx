import { LoadingState } from "@/components/ui/states";

export default function Loading() {
  return <LoadingState rows={6} />;
}
